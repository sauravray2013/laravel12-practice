<?php
namespace Saurav\Sril;
class C1{
    public function __construct(){
        echo "from class 2";
    }
}