<?php
require "namespace_class1.php";
require "namespace_class2.php";

new Saurav\C1();
new Saurav\Sril\C1();
