<?php
namespace Saurav;
class C1{
    public function __construct(){
        echo "from class 1";
    }
}